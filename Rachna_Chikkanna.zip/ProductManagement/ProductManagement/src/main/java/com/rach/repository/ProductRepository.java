package com.rach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rach.entity.ProductEntity;

public interface ProductRepository extends JpaRepository<ProductEntity, Integer>{

	List<ProductEntity> getProductBytype(String type);
	ProductEntity getProductById(Integer id);
}
