package com.rach.vo;

import java.io.Serializable;

import com.rach.entity.ProductEntity;

import lombok.Data;

@Data
public class ProductAndDescVO implements Serializable{

	private ProductEntity prEntity;
	private ProductDescVO prVo;
}
