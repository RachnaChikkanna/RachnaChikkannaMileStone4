package com.rach.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rach.entity.ProductEntity;
import com.rach.service.ProductClient;
import com.rach.service.ProductService;
import com.rach.vo.ProductAndDescVO;
import com.rach.vo.ProductDescVO;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	
	@GetMapping
	public List<ProductEntity> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@PostMapping
	public ProductEntity createProduct(@RequestBody ProductEntity prEntity) {
		return productService.addProduct(prEntity);
	}
	
	@GetMapping("byid/{id}")
	public ProductEntity getProductById(@PathVariable Integer id) {
		return productService.getProductById(id);
	}
	
	@GetMapping("bytype/{type}")
	public List<ProductEntity> getProductBytype(@PathVariable String type){
		return productService.getProductBytype(type);
	}
	
	@GetMapping("productanddesc/{id}")
	public ProductAndDescVO getProductwithDesc(@PathVariable Integer id) {
		return productService.getProductandService(id);
	}
	
}
