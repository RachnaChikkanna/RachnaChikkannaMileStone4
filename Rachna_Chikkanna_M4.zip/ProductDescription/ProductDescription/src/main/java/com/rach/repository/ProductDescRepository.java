package com.rach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rach.entity.ProductDescEntity;

public interface ProductDescRepository extends JpaRepository<ProductDescEntity, Integer>{

	
}
