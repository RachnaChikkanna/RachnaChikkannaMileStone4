package com.rach.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rach.service.ProductClient;
import com.rach.entity.ProductEntity;
import com.rach.repository.ProductRepository;
import com.rach.vo.ProductAndDescVO;
import com.rach.vo.ProductDescVO;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private ProductClient productClient;
	
	public List<ProductEntity> getAllProducts(){
		return productRepository.findAll();
	}
	
	public ProductEntity getProductById(Integer id) {
		return productRepository.findById(id).orElseThrow();
	}
	
	public ProductEntity addProduct(ProductEntity prEntity) {
		return productRepository.save(prEntity);
	}
	
	public List<ProductEntity> getProductBytype(String type){
		return productRepository.getProductBytype(type);
	}
	public ProductAndDescVO getProductandService(Integer id) {
		Optional<ProductEntity> optional = productRepository.findById(id);
		if(optional.isPresent()) {
			ProductEntity productEntity = optional.get();
			System.out.println(optional.get());
			Integer descid = productEntity.getId();
			ProductDescVO productDescVO = productClient.getProductDescVO(descid);
			ProductAndDescVO descVO = new ProductAndDescVO();
			descVO.setPrEntity(productEntity);
			descVO.setPrVo(productDescVO);
			return descVO;
		}
		return null;
	}
}
